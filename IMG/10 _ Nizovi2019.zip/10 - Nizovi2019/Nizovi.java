import java.util.Scanner;

public class Nizovi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a; // niz cijelih brojeva, referenca na niz a je trenutno null 
		// sljedeca naredba javl jer a nije inicijalzovan 
		// System.out.println(a);
		a = new int[5]; // 5 cijelih brojeva, svi imaju vrijenost 0
		System.out.println(a[3]); // stampa 0
		// System.out.println(a[6]); // stampa java.lang.ArrayIndexOutOfBoundsException: 6, jer niy ima samo 5 elemenata
		
		// niz od 10 realnih broejva, svi imaju vrijednost nula
		double [] b = new double[10]; 
		System.out.println(b.length); // broj elemenata niza
		
		// broj elemenata ne mora biti cjelobrojna konstanta
		int n, m = 15; 
		int [] c = new int[m]; // niz od 15 brojeva 0
		
		// ucitavamo broj elemenata niza 
		Scanner sc = new Scanner(System.in);
		System.out.println("Broj elemenata niza:");
		n = sc.nextInt();
		int [] d = new int[n];
		
		// elemente niza ucitavamo u ciklusu
		int cnt = 0; 
		for (cnt = 0; cnt<n; cnt++) {
			d[cnt] = sc.nextInt();
		}
		
		// stampanje niza
		System.out.println(d); // ovo stampa referencu na niz
		
		// stampanje elemenata niza
		for (cnt = 0; cnt<n; cnt++) {
			System.out.println(d[cnt]);
		}
		
		int [] e = {12,-23, 1, 32, 678, 1000, 32, 67, 12,-12, 245%6 }; // istovremena alkoacija memorije i zadavanje vrijednosti elemenata 
		// stampanje niza pomocu metoda printArray
		printArray(e); // stampanje elemenata niza e
		printArray(d); // stampanje elemenata niza d
		
		// sljedeci poziv prijavljuje gresku, jer b nije niz cijelih brojeva 
		// printArray(b); 
		
		// poziv metoda findElement
		System.out.println(findElement(32, e)); // stampa 3
		System.out.println(findElement(320, e)); // stampa -1
		
		// poziv metoda divisors
		int [] f = divisors(6);
		printArray(f);
		
		// kraca verzija prethodnog poziva
		printArray(divisors(6));
		
		// presumjeravanje referenci
		e = f; // e pokazuje ma memoriju na koju pokazuke i f; memorija nak oju je ranije pokazivao e (brojevi {12,-23, 1, 32, 678, 1000, 32, 67, 12,-12, 245%6 }) postaje tzv. garbage  
		printArray(e); // oba puta se stampa isti niz
		printArray(f); 
	}

	// primjer metoda koji ima niz kao argument
	// stampati elemente niya u jednom redu 
	public static void printArray(int [] arr) { // niz kako argument metoda
		for (int cnt = 0; cnt<arr.length-1; cnt++) { // arr.length - broj elemenata niza arr
			System.out.print(arr[cnt] + " "); // izmedju svak dva elementa po jedan blanko 
		}
		System.out.println(arr[arr.length-1]); // posljednji element
	}
	
	// drugi primjer metoda koji ima niz kao argument
	// vraca indeks broja prvog pojavljivanja broja f u nizu arr, ili broj -1 ako f nije u nizu
	public static int findElement(int f, int [] arr) { // niz kako argument metoda
		for (int cnt = 0; cnt<arr.length; cnt++) { // arr.length - broj elemenata niza arr
			if (f == arr[cnt]) {
				return cnt;
			}
		}
		return -1; 
	}	
	
	// primjer metoda koji vraca niz
	// vraca niz koji sadrzi najmanjih n brojeva ciji su jedini djelioci 2 ili 3  
	public static int [] divisors(int n) { 
		int [] rezultat = new int[n];
		int i = 2, cnt = 0; 
		while (cnt < n) {
			if (soleDivisors(i)) { // pomocni metod koji vraca true ako su 2 ili 3 jedini djelioci broja i 
				rezultat[cnt] = i;
				cnt++;
			}
			i++;
		}
		return rezultat;
	}
	
	// pomocni metod za prethodni zadatak
	// metod koji vraca true ako su 2 ili 3 jedini djelioci broja n 
	public static boolean soleDivisors(int n) {
		while (n%2 == 0) {
			n /= 2; 
		}
		while (n%3 == 0) {
			n /= 3; 
		}
		return n == 1;
	}
}
