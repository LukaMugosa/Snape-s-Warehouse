import javax.swing.JOptionPane;

public class Stringovi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s1 = "Nikola Tesla";
		 String s2 = "Nikola Tesla"; 
		 String s3 = new String("Nikola Tesla");
		 String s4 = new String("Nikola Tesla");
		 String s5 = new String(s1);
		 System.out.println("1==2:" + (s1 == s2));
		 System.out.println("1==3:" + (s1 == s3));
		 System.out.println("3==4:" + (s3 == s4));
		 System.out.println("3==5:" + (s3 == s5));
		 System.out.println("1==5:" + (s1 == s5));
		 s1 = "Aerodrom " + s1; 
		 System.out.println(s2.equals(s3));
		 System.out.println(s2.compareTo(s3)); 
		 System.out.println(s2.length());
		 System.out.println(s2.substring(2, 10).length());
		 System.out.println("Rolling Stones".indexOf("stones"));
		 System.out.println("Rolling Stones".indexOf('o'));
		 System.out.println("Rolling Stones".indexOf('o', 6));
		 String sent = "Ima mnogo    rijeci Aerodrom \'Nikola Tesla\' Beograd. Jos i Nis,Pristina,Berane"; 
		 String [] rijeci = sent.split("([\\s';,.:])+"); 
		 System.out.println("Broj rijeci:" + rijeci.length);
		 int i = 1;
		 System.out.println(sent.matches("\\w,+"));
		 for (int i = 0; i < rijeci.length; i++) {
			 System.out.println(i + " " + rijeci[i] + " " + rijeci[i].length());
		 }
		 
	}

}
